'''
This script runs Psalm and PHPStan and analyzes their output to create a report
setup.py needs to be ran before !
This script does the following steps:
    - Run Psalm
    - Run PHPStan
    - Run the custom codebasechecker script
    - Run report.py
'''
import argparse
import subprocess
import os
import json
import shutil
import sys

PSALM_OUTPUT="psalm-results.json"
PHPSTAN_OUTPUT="phpstan-results.json"
CODEBASECHECK_OUTPUT="codebaseCheck.json"

def parseArgs():
    parser = argparse.ArgumentParser(description="The PHPwn run script.")
     # Required positional argument
    parser.add_argument("src_dir", help="The source directory to analyze.")
    parser.add_argument("out_dir", help="The output directory.")
    # Optional flags
    parser.add_argument("--output-json", "-j", type=str, default="result.json", help="Report filename for json format")
    parser.add_argument("--output-csv", "-c", type=str, default="result.csv", help="Report filename for CSV format")
    parser.add_argument("--direct-serving", "-d", action="store_true", help="If the files are directly served on production. For accessible files check.")
    parser.add_argument("--htaccess-path","-H",type=str, default=".htaccess", help="The path of the .htaccess file from the root dir.")
    parser.add_argument("--accessible-files","-a",action="store_true",help="Pass this if you want PHPwn to check for accessbile files based on an .htaccess routing file.")
    args= parser.parse_args()
    return args.src_dir,args.out_dir,args.output_json,args.output_csv,args.direct_serving,args.htaccess_path,args.accessible_files

def runCommandOrFail(command,wd,allowCodes=[0],output=False):
    try:
        result= subprocess.run(command,cwd=wd,capture_output=True,text=True)
        if result.returncode not in allowCodes:
            print(f"STDOUT:\n {result.stdout}\n"+"-"*20)
            print(f"STDERR:\n {result.stderr}\n"+"-"*20)
            print(f"RETURN CODE: {result.returncode}"+"-"*20)
            if output:
                return False,""
            else:
                return False
        if output:
            return True,result.stdout
        else:
            return True
    except FileNotFoundError:
        print(f"[!] {command[0]} not found !")
        if output:
            return False,""
        else:
            return False

def run():
    srcDir,outDir,outputJson,outputCsv,directServing,htaccessPath,accessibleFiles= parseArgs()
    srcPath= os.path.join(outDir,os.path.basename(os.path.normpath(srcDir)))
    
    print("[+] Running Psalm. This may take a while...")
    ok,out=runCommandOrFail(["vendor/bin/psalm", "--taint-analysis", "--no-cache","--output-format=json"],srcPath,[0,2],output=True)
    if not ok:
        return False
    
    try:
        if os.path.exists(os.path.join(outDir,PSALM_OUTPUT)):
            os.remove(os.path.join(outDir,PSALM_OUTPUT))
        f= open(os.path.join(outDir,PSALM_OUTPUT),"w")
        json.dump(json.loads(out),f,indent=2)
        f.close()
    except Exception as e:
        print(f"[!] An error ocurred while trying to store the results of psalm in {PSALM_OUTPUT}: {e}")
        return False
    
    print("[+] Running PHPStan. This may take a while...")
    ok,out=runCommandOrFail(["vendor/bin/phpstan", "analyse", "--no-progress","--error-format=json"],srcPath,[0,1],output=True)
    if not ok:
        return False
    
    try:
        if os.path.exists(os.path.join(outDir,PHPSTAN_OUTPUT)):
            os.remove(os.path.join(outDir,PHPSTAN_OUTPUT))
        f= open(os.path.join(outDir,PHPSTAN_OUTPUT),"w")
        json.dump(json.loads(out),f,indent=2)
        f.close()
    except Exception as e:
        print(f"[!] An error ocurred while trying to store the results of PHPStan in {PHPSTAN_OUTPUT}: {e}")
        return False
    
    
    if accessibleFiles:
        print("[+] Running codebaseCheck. This may take a while...")
        ok,out=runCommandOrFail([sys.executable, "codebaseCheck.py", htaccessPath,".","--format=json"]+(["--direct-serving"] if directServing else []),srcPath,output=True)
        if not ok:
            return False
        
        try:
            if os.path.exists(os.path.join(outDir,CODEBASECHECK_OUTPUT)):
                os.remove(os.path.join(outDir,CODEBASECHECK_OUTPUT))
            f= open(os.path.join(outDir,CODEBASECHECK_OUTPUT),"w")
            json.dump(json.loads(out),f,indent=2)
            f.close()
        except Exception as e:
            print(f"An error ocurred while trying to store the results of codebaseCheck in {CODEBASECHECK_OUTPUT}: {e}")
            return False
        
    try:
        shutil.rmtree(srcPath)
    except FileNotFoundError as e:
        pass
    except Exception as e:
        print(f"[!] An error occurred: {e}")
        return False
        
    print("[+] Running report.py. This may take a while...")
    if not runCommandOrFail([sys.executable, "report.py", srcDir,PSALM_OUTPUT,PHPSTAN_OUTPUT,CODEBASECHECK_OUTPUT,"--output-json",outputJson,"--output-csv",outputCsv]+(["--accessible-files"] if accessibleFiles else []),outDir):
        return False
    print("[+] Running cleanReport.py. This may take a while...")
    if not runCommandOrFail([sys.executable, "cleanReport.py", outputJson],outDir):
        return False
    
    try:
        if accessibleFiles:
            os.remove(os.path.join(outDir,CODEBASECHECK_OUTPUT))
        os.remove(os.path.join(outDir,PSALM_OUTPUT))
        os.remove(os.path.join(outDir,PHPSTAN_OUTPUT))
        os.remove(os.path.join(outDir,"report.py"))
        os.remove(os.path.join(outDir,"cleanReport.py"))
    except Exception as e:
        print("[!] An error ocurred while cleaning up.")
        return False
        
    return True
    
if __name__=="__main__":
    if run():
        print(f"[+] Analysis finished. Look at the output files !")
        sys.exit(0)
    else:
        print("[!] An error ocurred during Analysis.")
        sys.exit(1)